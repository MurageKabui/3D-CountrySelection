const config = {
  scaleFactor: 0.75,
  angles: { x: -100, y: -20, z: 0 },
  colors: {
      water: '#111',
      land: '#424447',
      hover: '#eee'
  }
};

const state = {
  currentCountry: null,
  isDragging: false,
  startX: 0,
  startY: 0
};

const elements = {
  countryLabel: d3.select('#countryLabel'),
  canvas: d3.select('#globe'),
  context: d3.select('#globe').node().getContext('2d')
};

const projection = d3.geoOrthographic().precision(0.1);
const path = d3.geoPath(projection).context(elements.context);
let land, countries, countryList;

const setAngles = () => {
  const rotation = projection.rotate();
  rotation[0] = config.angles.x;
  rotation[1] = config.angles.y;
  rotation[2] = config.angles.z;
  projection.rotate(rotation);
};

const scale = () => {
  const width = document.documentElement.clientWidth * config.scaleFactor;
  const height = document.documentElement.clientHeight * config.scaleFactor;
  elements.canvas.attr('width', width).attr('height', height);
  projection
    .scale(Math.min(width, height) / 2)
    .translate([width / 2, height / 2]);
  render();
};

const dragstarted = (event) => {
  state.isDragging = true;
  state.startX = event.x;
  state.startY = event.y;
};

const dragged = (event) => {
  if (!state.isDragging) { return } ;

  const sensitivity = 0.25; // Adjust the sensitivity of rotation

  const dx = (event.x - state.startX) * sensitivity;
  const dy = (event.y - state.startY) * sensitivity;

  state.startX = event.x;
  state.startY = event.y;

  const rotation = projection.rotate();
  rotation[0] += dx;
  rotation[1] -= dy;
  projection.rotate(rotation);

  render();
};

const dragended = () => {
  state.isDragging = false;
};

const render = () => {
  const { context } = elements;
  const width = document.documentElement.clientWidth;
  const height = document.documentElement.clientHeight;
  context.clearRect(0, 0, width, height);
  fill({ type: 'Sphere' }, config.colors.water);

  fill(land, config.colors.land);

  if (state.currentCountry) {
      elements.countryLabel.style('color', 'white')
      fill(state.currentCountry, config.colors.hover);
  }
};

const fill = (obj, color) => {
  elements.context.beginPath();
  path(obj);
  elements.context.fillStyle = color;
  elements.context.fill();
};

const loadData = async (cb) => {
  const world = await d3.json('https://unpkg.com/world-atlas@2.0.2/countries-110m.json');
  let countryNames = await d3.tsv('https://gist.githubusercontent.com/mbostock/4090846/raw/07e73f3c2d21558489604a0bc434b3a5cf41a867/world-country-names.tsv');
  countryNames[110].name = "Palestine"

  cb(world, countryNames);
};

const getCountry = (event) => {
  const pos = projection.invert(d3.pointer(event));
  return countries.features.find((f) =>
      f.geometry.coordinates.find((c1) =>
      d3.polygonContains(c1, pos) || c1.some((c2) => d3.polygonContains(c2, pos))
      )
  );
};

const mousemove = (event) => {
  const country = getCountry(event);
  if (!country) {
      if (state.currentCountry) {
          leave(state.currentCountry);
          state.currentCountry = null;
          render();
      }
      return;
  }
  if (country === state.currentCountry) {
      return;
  }
  state.currentCountry = country;
  render();
  enter(country);
};

const enter = (country) => {
  const name = countryList.find((c) => parseInt(c.id) === parseInt(country.id))?.name || '';
  elements.countryLabel.text(name);
};

const leave = (country) => {
  elements.countryLabel.text('');
};

const click = (event) => {
  const country = getCountry(event);
  if (country) {
    const name = countryList.find((c) => parseInt(c.id) === parseInt(country.id))?.name || '';
    alert(`Selected country: ${name}`);
  }
};

export const init = () => {
  setAngles();
  loadData((world, cList) => {
    land = topojson.feature(world, world.objects.land);
    countries = topojson.feature(world, world.objects.countries);
    countryList = cList;

    window.addEventListener('resize', scale);
    scale();

    // Attach event handlers after data is loaded
    elements.canvas.call(
      d3.drag()
        .on('start', dragstarted)
        .on('drag', dragged)
        .on('end', dragended)
    ).on('mousemove', mousemove)
      .on('touchmove', mousemove)
      .on('click', click);
  });
};

init()